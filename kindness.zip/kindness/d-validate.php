<?php
	$conn=mysqli_connect("localhost","root","","charity") or die("could not find conn");
	$db=mysqli_select_db($conn,"charity") or die("could not find db");
	if(isSet($_REQUEST["register"]))
	{
		$name=$_REQUEST["name"];
		$email=$_REQUEST["email"];
		$pwd=$_REQUEST["pwd"];
		$address=$_REQUEST["address"];
		$contact=$_REQUEST["contact"];
		$q="select * from donor where email='$email';";
		$val=mysqli_query($conn,$q);
		$n=mysqli_num_rows($val);
		if($n==0)
		{
			$q="INSERT INTO donor (name, email, pwd, address, contact) VALUES ('$name', '$email', '$pwd', '$address', '$contact');";
			mysqli_query($conn,$q);
			session_start();
			$_SESSION['reg']="true";
			if(isSet($_SESSION['reg']))
				header('Location: donor-login.php');
		}
		else
		{
			session_start();
			$_SESSION['user_exists']="true";
			if(isSet($_SESSION['user_exists']))
				header('Location: donor-login.php');
		}
	}
	
	if(isSet($_REQUEST["login"]))
	{
		$email=$_REQUEST["email"];
		$pwd=$_REQUEST["pwd"];
		$q="select * from donor where email='$email';";
		$val=mysqli_query($conn,$q);
		$n=mysqli_num_rows($val);
		if($n==1)
		{
			$q="select pwd,name from donor where email='$email';";
			$arr=mysqli_query($conn,$q);
			$row=mysqli_fetch_array($arr,MYSQLI_BOTH);
			if($pwd == $row['pwd'])
			{
				//$name="select name from donor where email='$email';";
				//$arr1=mysqli_query($conn,$name);
				//$row1=mysqli_fetch_array($arr1,MYSQLI_BOTH);
				setcookie("email","$email");
				header('Location: donor.php');
			}
			else
			{
				session_start();
				$_SESSION['pass']="true";
				if(isSet($_SESSION['pass']))
					header('Location: donor-login.php');
			}
		}
		else
		{
			session_start();
			$_SESSION['no_user']="true";
			if(isSet($_SESSION['no_user']))
				header('Location: donor-login.php');
		}
		
	}
?>